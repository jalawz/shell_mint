#!/bin/bash

# Define the sed command
sed_command="sed -i '1917i\\  width: 50px !important;\\n  margin: 0px 2px;'"

# Loop through the specified themes and apply sed command
themes=("Dark-Compact" "Green-Dark-Compact" "Green-Light-Compact" "Grey-Dark-Compact" "Grey-Light-Compact" "Light-Compact" "Orange-Dark-Compact" "Orange-Light-Compact" "Pink-Dark-Compact" "Pink-Light-Compact" "Purple-Dark-Compact" "Purple-Light-Compact" "Red-Dark-Compact" "Red-Light-Compact" "Teal-Dark-Compact" "Teal-Light-Compact" "Yellow-Dark-Compact" "Yellow-Light-Compact")

for theme in "${themes[@]}"
do
    file_path="$HOME/.themes/Orchis-$theme/cinnamon/cinnamon.css"
    eval "$sed_command $file_path"
done

