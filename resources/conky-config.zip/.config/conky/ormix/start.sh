#!/bin/bash

killall conky
sleep 2s

conky -c $HOME/.config/conky/ormix/config/clock-date.conf &> /dev/null &
conky -c $HOME/.config/conky/ormix/config/weather-info.conf &> /dev/null &
conky -c $HOME/.config/conky/ormix/config/music-play.conf &> /dev/null &

exit
